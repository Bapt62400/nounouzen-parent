// Fichier JS React simulé
document.getElementById("root").innerHTML = `
  <h1>Nounou Zen</h1>
  <p>Bienvenue sur votre vraie appli React !</p>
  <p>Navigation, profils, favoris, filtres à venir...</p>
`;
